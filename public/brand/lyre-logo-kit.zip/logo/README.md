# Logo Kit — LYRE SOCIAL

Identity: the **lyre mark** — an original classical lyre (scroll volutes, U bowl, architrave crossbar, four strings, pedestal foot; 30/512 body stroke, round caps), the Marcellus wordmark, and the lava seam. Use the files; never redraw the lyre. Files are SVG with a webfont @import — they render correctly opened in a browser or inlined; for production print/app-store use, have the type outlined to paths by a type-licensed designer (flagged in readme).

Files
- lyre-carbon.svg / lyre-paper.svg — the mark alone (light / dark)
- lockup-horizontal-carbon.svg / -paper.svg — lyre + inline wordmark + seam
- lockup-vertical-paper.svg — lyre over stacked wordmark
- roundel-paper.svg — badge ring with circular type (patches, stamps, coasters)
- appicon-lyre.svg — app icon (lyre + seam); mark-appicon.svg / -light.svg — type monogram ("L" + seam) alternate icon/avatar; favicon.svg — 64px simplified (3 strings)
- wordmark-carbon.svg — plain tracked wordmark, light surfaces (transparent bg, no seam)
- wordmark-paper.svg — plain tracked wordmark, reversed on carbon
- stacked-paper.svg — stacked lockup (LYRE / seam / SOCIAL)
- mark-appicon.svg / mark-appicon-light.svg — monogram tile ("L" + seam), app icon & avatar
- seam.svg — the lava seam device on its own
- og-banner.svg — 1200×630 social/OG banner

Rules (also on the brand-kit page)
- Clear space: one cap-height on all sides. Min width: 120px inline wordmark; 24px monogram.
- Carbon on light, paper on dark. The seam is the only color — never recolor the letters.
- Never: bold, italic, arc, drop-shadow, redraw or restyle the lyre, fill its strokes, or run gradient through the mark or the letters — the seam is the only place the lava lives. Event themes may swap the seam gradient; letters and mark never change.
- Hierarchy: horizontal lockup is primary; plain wordmark for editorial/print; mark alone once the context knows us; roundel for physical goods; monogram or lyre icon for avatars; favicon only below 32px.